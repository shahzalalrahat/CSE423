from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *

import random

W_Width, W_Height = 500, 500
ballx = bally = 0
speed = 0.01
ball_size = 2
create_new = False

class Point:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.z = 0

def crossProduct(a, b):
    result = Point()
    result.x = a.y * b.z - a.z * b.y
    result.y = a.z * b.x - a.x * b.z
    result.z = a.x * b.y - a.y * b.x

    return result

def convert_coordinate(x, y):
    global W_Width, W_Height
    a = x - (W_Width / 2)
    b = (W_Height / 2) - y 
    return a, b

def draw_points(x, y, s):
    glPointSize(s)
    glBegin(GL_POINTS)
    glVertex2f(x, y)
    glEnd()

def build_house():
    glColor3f(0.0, 1.0, 0.0)  # Green color for the house
    glBegin(GL_TRIANGLES)
    glVertex2f(-100, 0)
    glVertex2f(100, 0)
    glVertex2f(0, 50)
    glEnd()

    glLineWidth(5)
    glBegin(GL_LINES)

    glVertex2f(-80, 0)
    glVertex2f(-80, -100)

    glVertex2f(80, 0)
    glVertex2f(80, -100)

    glVertex2f(-80, -100)
    glVertex2f(80, -100)
    glEnd()
    
    glLineWidth(2)
    glBegin(GL_LINES)

    glVertex2f(-57, -97)
    glVertex2f(-57, -32)

    glVertex2f(-57, -32)
    glVertex2f(-25, -32)

    glVertex2f(-25, -32)
    glVertex2f(-25, -97)

    glVertex2f(8, -30)
    glVertex2f(48, -30)

    glVertex2f(8, -65)
    glVertex2f(48, -65)

    glVertex2f(8, -30)
    glVertex2f(8, -65)

    glVertex2f(48, -30)
    glVertex2f(48, -65)

    glVertex2f(27, -30)
    glVertex2f(27, -65)

    glVertex2f(7, -46)
    glVertex2f(46, -46)

    glEnd()

    glPointSize(5)
    glBegin(GL_POINTS)
    glVertex2f(-35, -60)
    glEnd()

raindrop = []
for x in range(-450, 450, 5):
    for c in range(450 - random.randrange(30, 40), 20, -random.randrange(30, 40)):
        y1 = c
        y2 = y1 - 20
        raindrop += [[x, y1, x, y2]]

def draw_rain():
    glBegin(GL_LINES)
    for i in raindrop:
        glVertex2f(i[0], i[1])
        glVertex2f(i[2], i[3])
    glEnd()

r, o, n, g = 0.0, 0.0, 0.0, 0.0

def keyboardListener(key, x, y):
    global r, o, n, g
    if key == b'd':
        print("Night to Day")
        r += 0.1
        o += 0.1
        n += 0.1
        g += 0.1
    if key == b'n':
        print("Day to Night")
        r -= 0.1
        o -= 0.1
        n -= 0.1
        g -= 0.1
    glutPostRedisplay()

left = False
right = False
straight = True

def specialKeyListener(key, x, y):
    global raindrop, left, right, straight
    if key == GLUT_KEY_LEFT:
        if straight:
            left = True
            straight = False
            for i in raindrop:
                i[2] -= i[1] - i[3]
            print("Left")
        elif right:
            straight = True
            right = False
            for i in raindrop:
                i[2] -= i[1] - i[3]
            print('Straight')
        elif left:
            print('Already Left')
    if key == GLUT_KEY_RIGHT:
        if left:
            straight = True
            left = False
            for i in raindrop:
                i[2] += i[1] - i[3]
            print('Straight')
        elif straight:
            right = True
            straight = False
            for i in raindrop:
                i[2] += i[1] - i[3]
            print('Right')
        elif right:
            print('Already Right')
    print(left, straight, right)
    glutPostRedisplay()

def mouseListener(button, state, x, y):
    global ballx, bally, create_new
    if button == GLUT_LEFT_BUTTON:
        if state == GLUT_DOWN:    
            c_X, c_y = convert_coordinate(x, y)
            ballx, bally = c_X, c_y
            print(c_X, c_y)
    if button == GLUT_RIGHT_BUTTON:
        if state == GLUT_DOWN:     
            create_new = convert_coordinate(x, y)
    glutPostRedisplay()

def display():
    #clear the display
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glClearColor(r, o, n, g) #//color black
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    #load the correct matrix -- MODEL-VIEW matrix
    glMatrixMode(GL_MODELVIEW)
    #initialize the matrix
    glLoadIdentity()
    gluLookAt(0, 0, 200, 0, 0, 0, 0, 1, 0)
    # glMatrixMode(GL_MODELVIEW)
    build_house()
    draw_rain()
    glutSwapBuffers()

def animate():
    glutPostRedisplay()
    global raindrop, left, right, straight
    for i in range(len(raindrop)):
        if raindrop[i][1] >= 20:
            if straight:
                raindrop[i][1] -= 0.1
                raindrop[i][3] -= 0.1
            if left:
                raindrop[i][0] -= 0.1
                raindrop[i][1] -= 0.1
                raindrop[i][2] -= 0.1
                raindrop[i][3] -= 0.1
            if right:
                raindrop[i][0] += 0.1
                raindrop[i][1] -= 0.1
                raindrop[i][2] += 0.1
                raindrop[i][3] -= 0.1
        else:
            if straight:
                raindrop[i][1] += 450
                raindrop[i][3] += 450
            if left:
                raindrop[i][0] += 450
                raindrop[i][1] += 450
                raindrop[i][2] += 450
                raindrop[i][3] += 450
            if right:
                raindrop[i][0] -= 450
                raindrop[i][1] += 450
                raindrop[i][2] -= 450
                raindrop[i][3] += 450

def init():
    glClearColor(0, 0, 0, 0)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(104, 1, 1, 1000.0)

glutInit()
glutInitWindowSize(W_Width, W_Height)
glutInitWindowPosition(0, 0)
glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB)

wind = glutCreateWindow(b"OpenGL Coding Practice")
init()

glutDisplayFunc(display)
glutIdleFunc(animate)
glutKeyboardFunc(keyboardListener)
glutSpecialFunc(specialKeyListener)
glutMouseFunc(mouseListener)

glutMainLoop()
