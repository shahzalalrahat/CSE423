from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
import math

W_Width,W_Height=400,450
ballx=bally=0
speed=1
ball_size=2
new=False

def draw_points(x, y, s):
    glPointSize(s)
    glBegin(GL_POINTS)
    glVertex2f(x,y)
    glEnd()

def specialKeyListener(key, x, y):
    global gb1,gb2,gb3,gb4
    speedCount=20
    if key== GLUT_KEY_RIGHT:
        if gb1[2]>=250:
            pass
        else:
            if pause==False:
                gb1[0]+=speedCount
                gb1[2]+=speedCount
                gb2[0]+=speedCount
                gb2[2]+=speedCount
                gb3[0]+=speedCount
                gb3[2]+=speedCount
                gb4[0]+=speedCount
                gb4[2]+=speedCount
    if key==GLUT_KEY_LEFT:
        if gb1[0]<=-250:
            pass
        else:
            if pause==False:
                gb1[0]-=speedCount
                gb1[2]-=speedCount
                gb2[0]-=speedCount
                gb2[2]-=speedCount
                gb3[0]-=speedCount
                gb3[2]-=speedCount
                gb4[0]-=speedCount
                gb4[2]-=speedCount
    glutPostRedisplay()

def mouseListener(button, state, x, y):
    global initY, gameInfo, pause, bColor

    # Check if the left mouse button was pressed down
    if button == GLUT_LEFT_BUTTON and state == GLUT_DOWN:
        # Exit button area
        if 360 <= x <= 390 and 15 <= y <= 45:
            glutLeaveMainLoop()

        # Pause/Resume toggle button area
        elif 170 <= x <= 220 and 10 <= y <= 45:
            pause = not pause  # Toggle the pause state

        # Restart button area
        elif 6 <= x <= 50 and 10 <= y <= 45:
            initY = 210  # Reset the initial Y position
            gameInfo = 0  # Reset the game information or score
            pause = False  # Ensure the game is not paused after restart
            bColor = [1, 1, 1]  # Reset the ball color to white
            print('Starting Over!')

    # Redraw the scene
    glutPostRedisplay()


def MidPointLine(x1, y1, x2, y2):
    store=[]
    dx=x2-x1
    dy=y2-y1
    d=2*dy-dx
    pE=2*dy
    pNE=2*dy-2*dx
    x=x1
    y=y1
    for i in range(x,x2+1):
        store+=[[i,y]]
        if d>0:
            d+=pNE
            y+=1
        else:
            d+=pE
    return store

def findZone(x1, y1, x2, y2):
    dx = x2 - x1
    dy = y2 - y1
    abs_dx = abs(dx)
    abs_dy = abs(dy)

    if dx > 0 and dy >= 0:
        return 0 if abs_dx > abs_dy else 1
    elif dx <= 0 and dy > 0:
        return 3 if abs_dx > abs_dy else 2
    elif dx < 0 and dy <= 0:
        return 4 if abs_dx > abs_dy else 5
    elif dx >= 0 and dy < 0:
        return 7 if abs_dx > abs_dy else 6

    return -1  # In case none of the above conditions are met

        
def convertToZone0(zone, x1, y1, x2, y2):
    if zone==1:
        x1,y1=y1,x1
        x2,y2=y2,x2
    elif zone==2:
        x1,y1=y1,-x1
        x2,y2=y2,-x2
    elif zone==3:
        x1,y1=-x1,y1
        x2,y2=-x2,y2
    elif zone==4:
        x1,y1=-x1,-y1
        x2,y2=-x2,-y2
    elif zone==5:
        x1,y1=-y1,-x1
        x2,y2=-y2,-x2
    elif zone==6:
        x1,y1=-y1,x1
        x2,y2=-y2,x2
    elif zone==7:
        x1,y1=x1,-y1
        x2,y2=x2,-y2
    return x1,y1,x2,y2

def convertToZoneM(color, zone, points):
    s=2
    glColor3f(color[0], color[1], color[2])
    if zone==0:
        for x,y in points:
            draw_points(x,y,s)
    elif zone==1:
        for x,y in points:
            draw_points(y,x,s)
    elif zone==2:
        for x,y in points:
            draw_points(-y,x,s)
    elif zone==3:
        for x,y in points:
            draw_points(-x,y,s)
    elif zone==4:
        for x,y in points:
            draw_points(-x,-y,s)
    elif zone==5:
        for x,y in points:
            draw_points(-y,-x,s)
    elif zone==6:
        for x,y in points:
            draw_points(y,-x,s)
    elif zone==7:
        for x,y in points:
            draw_points(x,-y,s)

def drawLines(color, x1, y1, x2, y2):
    zone=findZone(x1,y1,x2,y2)
    x1,y1,x2,y2=convertToZone0(zone,x1,y1,x2,y2)
    points=MidPointLine(x1,y1,x2,y2)
    convertToZoneM(color,zone,points)

import random 
xRandom=50
initY=210
gb1=[-70,-235,70,-235]
gb2=[-50,-250,50,-250]
gb3=[-50,-250,-70,-235]
gb4=[50,-250,70,-235]
pause=False
bColor=[1,1,1]
R3color=random.random()

ranColor=[R3color,R3color,R3color]
def display():
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glClearColor(0,0,0,0);	
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glMatrixMode(GL_MODELVIEW)
    glLoadIdentity()
    gluLookAt(0,0,200,0,0,0,0,1,0)
    glMatrixMode(GL_MODELVIEW)
    #======================================================================================
    global gb1,gb2,gb3,gb4,bColor,ranColor
    drawLines(bColor,gb1[0],gb1[1],gb1[2],gb1[3])
    drawLines(bColor,gb2[0],gb2[1],gb2[2],gb2[3])
    drawLines(bColor,gb3[0],gb3[1],gb3[2],gb3[3])
    drawLines(bColor,gb4[0],gb4[1],gb4[2],gb4[3])
    

    color=[1,0,0]   #Exit button creation
    drawLines(color,240,240,210,210)
    drawLines(color,240,210,210,240)
    

    color=[1,0.984,0]   #Pause button creation
    if pause==False:
        drawLines(color,5,210,5,240)
        drawLines(color,-5,210,-5,240)
    else:
        drawLines(color,-15,210,-15,240)
        drawLines(color,-15,240,20,225)
        drawLines(color,-15,210,20,225)


    color=[0,0,1]   #Restart mechanism
    drawLines(color,-200,225,-240,225)
    drawLines(color,-218,240,-240,225)
    drawLines(color,-218,210,-240,225)


    color=[0,0,0]  #Diamond structure drawing
    size1=20
    size2=30
    global xRandom,initY
    drawLines(color,xRandom,initY,xRandom+size1,initY)
    drawLines(color,xRandom,initY-size2,xRandom+size1,initY-size2)
    drawLines(color,xRandom,initY-size2,xRandom,initY)
    drawLines(color,xRandom+size1,initY-size2,xRandom+size1,initY)
    p1=[int((xRandom+xRandom+size1)/2),initY]
    p2=[xRandom+size1,int((initY+initY-size2)/2)]
    p3=[p1[0],initY-size2]
    p4=[xRandom,p2[1]]
    color=[0.950,0.920,0.550]
    drawLines(ranColor,p1[0],p1[1],p2[0],p2[1])
    drawLines(ranColor,p2[0],p2[1],p3[0],p3[1])
    drawLines(ranColor,p3[0],p3[1],p4[0],p4[1])
    drawLines(ranColor,p4[0],p4[1],p1[0],p1[1])
    glutSwapBuffers()

gameInfo=0
import random

def animate():
    global xRandom, initY, gb1, gameInfo, R3color, pause, bColor, ranColor

    # This function is called periodically to update the game state.
    if pause:
        # If the game is paused, we simply skip the rest of the update logic.
        return
    
    # Lower the diamond each frame unless the game is paused.
    initY -= 1  # Assuming 'speed' is 1; adjust as needed.
    
    # Check if the diamond has reached the bottom of the game area.
    if initY == -214:
        # Check if the diamond's position intersects with gb1 boundaries.
        if gb1[0] < xRandom + 20 and gb1[2] > xRandom:
            # If it intersects, reset the position and increase the score.
            initY = 210
            xRandom = random.randint(-250, 230)
            gameInfo += 1
            ranColor = [R3color, R3color, R3color]
            print(f'Score: {gameInfo}')
        else:
            # If it does not intersect, the game is over.
            bColor = [1, 0, 0]
            print(f'Game Over! Score: {gameInfo}')
    
    # Always request a redraw at the end of the function.
    glutPostRedisplay()


def init():
    glClearColor(0,0,0,0)
    glMatrixMode(GL_PROJECTION)
    glLoadIdentity()
    gluPerspective(104,1,1,1000.0)
    
glutInit()
glutInitWindowSize(W_Width,W_Height)
glutInitWindowPosition(500, 0)
glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGB)
wind = glutCreateWindow(b"Diamond Game")
init()
glutDisplayFunc(display)
glutIdleFunc(animate)
#glutKeyboardFunc(keyboardListener)
glutSpecialFunc(specialKeyListener)
glutMouseFunc(mouseListener)
glutMainLoop()

